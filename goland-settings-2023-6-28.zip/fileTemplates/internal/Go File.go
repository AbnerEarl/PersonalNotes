/**
 * @author: ${USER}
 * @email 1320259466@qq.com
 * @date: ${DATE} ${TIME}
 * @desc: about the role of class.
 */

package ${GO_PACKAGE_NAME}
